---
created: 2025-12-05
modified: 2025-12-05 13:37:25
accessed: 2025-12-05 13:58:05
---
<%*
  console.log("[TIMES-DEBUG] startup hook template running");
  await tp.user.templater_times_debug.register_times_hook();
%>
